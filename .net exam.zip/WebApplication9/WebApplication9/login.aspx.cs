﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication9
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string na = name.Text;
            string password = pass.Text;

            SqlConnection con = new SqlConnection();
            con.ConnectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=c:\users\user1\documents\visual studio 2015\Projects\WebApplication9\WebApplication9\App_Data\shop.mdf;Integrated Security=True";
            try
            {
                using (con)
                {
                    string command = "SELECT * from Customer_info where CustomerName = '"+ na +"' and Password='"+password+"'"  ;
                    SqlCommand cmd = new SqlCommand(command, con);
                    con.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();
                    if(rdr!=null)
                    {
                        Response.Redirect("Products.aspx");
                    }
                    else
                    {
                        wrong.Text = "Wrong Credentials";
                    }
                    rdr.Close();
                }

            }
            catch (Exception ex)
            {
                Response.Write("Errors: " + ex.Message);
            }
           
        }
    }
}