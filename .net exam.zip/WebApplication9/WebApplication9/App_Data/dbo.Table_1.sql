﻿CREATE TABLE [dbo].[Customer_info]
(
	[Customerid] INT NOT NULL PRIMARY KEY IDENTITY, 
    [Password] NCHAR(10) NULL, 
    [CustomerName] NCHAR(50) NULL, 
    [Contact] NCHAR(10) NULL
)
