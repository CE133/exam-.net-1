﻿CREATE TABLE [dbo].[Order_info]
(
	[Order_id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [Product_id] INT NULL, 
    [Customerid] INT NULL, 
    [Amount] INT NULL, 
    CONSTRAINT [FK_Order_info_ToTable] FOREIGN KEY ([Product_id]) REFERENCES [Product_info]([Product_id])
)
