﻿CREATE TABLE [dbo].[Product_info]
(
	[Product_id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [ProductName] NCHAR(60) NULL, 
    [ProductCategory] NCHAR(160) NULL, 
    [ExpiryDate] DATE NULL
)
