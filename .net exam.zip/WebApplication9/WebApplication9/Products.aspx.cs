﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication9
{
    public partial class Products : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                SqlConnection con = new SqlConnection();
                con.ConnectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=c:\users\user1\documents\visual studio 2015\Projects\WebApplication9\WebApplication9\App_Data\shop.mdf;Integrated Security=True";
                try
                {
                    using (con)
                    {
                        string command = "Select *  from Product_info";
                        SqlCommand cmd = new SqlCommand(command, con);
                        con.Open();
                        SqlDataReader rdr = cmd.ExecuteReader();
                        while (rdr.Read())
                        {
                            ListItem item = new ListItem();
                            item.Text = rdr["ProductCategory"].ToString();
                            category.Items.Add(item);
                        }
                        rdr.Close();
                    }
                }
                catch (Exception ex)
                {
                    Response.Write("Errors: " + ex.Message);
                }
            }
        }

        protected void btnShow_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=c:\users\user1\documents\visual studio 2015\Projects\WebApplication9\WebApplication9\App_Data\shop.mdf;Integrated Security=True";
            try
            {
                using (con)
                {
                    string command = "Select ProductName from Product_info where ProductCategory='" + category.SelectedItem.Text + "'";
                    SqlCommand cmd = new SqlCommand(command, con);
                    con.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();
                    GridViewOrders.DataSource = rdr;
                    GridViewOrders.DataBind();
                    rdr.Close();
                }
            }
            catch (Exception ex)
            {
                Response.Write("Errors: " + ex.Message);
            }
        }
    }
}